from django.urls import path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from accounts.views import MeView, AdminCreateUserView, AdminReplaceUserRolesView, AdminListRolesView

urlpatterns = [
    path("login", TokenObtainPairView.as_view(), name="auth-login"),
    path("refresh", TokenRefreshView.as_view(), name="auth-refresh"),
    path("me", MeView.as_view(), name="auth-me"),

    # RBAC admin endpoints
    path("admin/roles", AdminListRolesView.as_view(), name="admin-list-roles"),
    path("admin/users", AdminCreateUserView.as_view(), name="admin-create-user"),
    path("admin/users/<int:user_id>/roles", AdminReplaceUserRolesView.as_view(), name="admin-replace-user-roles"),
]
