from __future__ import annotations

from django.contrib.auth import get_user_model
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated

from accounts.models import Role, UserRole
from accounts.serializers import MeSerializer, AdminCreateUserSerializer, ReplaceRolesSerializer, RoleSerializer
from accounts.permissions import IsAdminUser

User = get_user_model()


class MeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response(MeSerializer(request.user).data)


class AdminCreateUserView(APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]

    def post(self, request):
        ser = AdminCreateUserSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        user = ser.save()
        return Response(
            {"id": user.id, "email": user.email, "roles": list(user.user_roles.values_list("role__slug", flat=True))},
            status=status.HTTP_201_CREATED
        )


class AdminReplaceUserRolesView(APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]

    def post(self, request, user_id: int):
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response({"detail": "User not found"}, status=status.HTTP_404_NOT_FOUND)

        ser = ReplaceRolesSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        roles = ser.validated_data["roles"]

        UserRole.objects.filter(user=user).delete()
        for slug in roles:
            role = Role.objects.get(slug=slug)
            UserRole.objects.create(user=user, role=role)

        return Response({"status": "ok", "user_id": user.id, "roles": roles})


class AdminListRolesView(APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request):
        roles = Role.objects.order_by("slug")
        return Response(RoleSerializer(roles, many=True).data)
