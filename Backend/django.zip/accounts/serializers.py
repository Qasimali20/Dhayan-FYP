from __future__ import annotations

from rest_framework import serializers
from django.contrib.auth import get_user_model
from accounts.models import Role, UserRole

User = get_user_model()


class MeSerializer(serializers.ModelSerializer):
    roles = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ("id", "email", "full_name", "is_staff", "is_active", "roles")

    def get_roles(self, obj):
        return list(obj.user_roles.select_related("role").values_list("role__slug", flat=True))


class AdminCreateUserSerializer(serializers.Serializer):
    email = serializers.EmailField()
    full_name = serializers.CharField(required=False, allow_blank=True, default="")
    password = serializers.CharField(min_length=10, write_only=True)
    is_active = serializers.BooleanField(default=True)
    roles = serializers.ListField(child=serializers.SlugField(), required=False, default=list)

    def validate_roles(self, roles):
        missing = [r for r in roles if not Role.objects.filter(slug=r).exists()]
        if missing:
            raise serializers.ValidationError(f"Unknown roles: {', '.join(missing)}")
        return roles

    def create(self, validated_data):
        roles = validated_data.pop("roles", [])
        password = validated_data.pop("password")
        user = User.objects.create_user(password=password, **validated_data)
        for slug in roles:
            role = Role.objects.get(slug=slug)
            UserRole.objects.get_or_create(user=user, role=role)
        return user


class ReplaceRolesSerializer(serializers.Serializer):
    roles = serializers.ListField(child=serializers.SlugField(), min_length=0)

    def validate_roles(self, roles):
        missing = [r for r in roles if not Role.objects.filter(slug=r).exists()]
        if missing:
            raise serializers.ValidationError(f"Unknown roles: {', '.join(missing)}")
        return roles


class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = ("id", "slug", "name")
