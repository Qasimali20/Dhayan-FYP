from __future__ import annotations

from django.conf import settings
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.utils import timezone

from therapy.models import SessionTrial


def speech_audio_upload_path(instance: "SpeechTrialAudio", filename: str) -> str:
    ts = timezone.now().strftime("%Y/%m/%d")
    return f"speech_audio/{ts}/trial_{instance.trial_id}/{filename}"


class SpeechTrialMeta(models.Model):
    """
    Speech-specific metadata attached to a generic SessionTrial.
    We do NOT replace SessionTrial — we extend it.
    """
    id = models.BigAutoField(primary_key=True)
    trial = models.OneToOneField(SessionTrial, on_delete=models.CASCADE, related_name="speech_meta")

    target_text = models.CharField(max_length=200, blank=True, default="")
    target_phoneme = models.CharField(max_length=50, blank=True, default="")
    category = models.CharField(max_length=120, blank=True, default="")
    language = models.CharField(max_length=10, blank=True, default="en")

    difficulty = models.IntegerField(default=1, validators=[MinValueValidator(1), MaxValueValidator(10)])

    therapist_transcript = models.CharField(max_length=500, blank=True, default="")

    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        indexes = [
            models.Index(fields=["category", "language"]),
            models.Index(fields=["difficulty"]),
        ]

    def __str__(self) -> str:
        return f"SpeechTrialMeta(trial={self.trial_id}, target={self.target_text})"


class SpeechTrialAudio(models.Model):
    """
    Stores uploaded audio for a speech trial (MVP: one audio per trial).
    """
    id = models.BigAutoField(primary_key=True)
    trial = models.OneToOneField(SessionTrial, on_delete=models.CASCADE, related_name="speech_audio")

    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="speech_audio_uploads")
    uploaded_at = models.DateTimeField(default=timezone.now)

    content_type = models.CharField(max_length=120, blank=True, default="")
    size_bytes = models.BigIntegerField(default=0)
    duration_ms = models.IntegerField(null=True, blank=True)

    file = models.FileField(upload_to=speech_audio_upload_path)

    class Meta:
        indexes = [
            models.Index(fields=["uploaded_at"]),
            models.Index(fields=["trial"]),
        ]

    def __str__(self) -> str:
        return f"SpeechTrialAudio(trial={self.trial_id}, size={self.size_bytes})"


class ASRJob(models.Model):
    class Status(models.TextChoices):
        QUEUED = "queued", "Queued"
        RUNNING = "running", "Running"
        SUCCEEDED = "succeeded", "Succeeded"
        FAILED = "failed", "Failed"

    id = models.BigAutoField(primary_key=True)

    # Keep jobs attached to trial (works even if audio changes later)
    trial = models.ForeignKey(SessionTrial, on_delete=models.CASCADE, related_name="asr_jobs")

    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="asr_jobs_created")
    created_at = models.DateTimeField(default=timezone.now)

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.QUEUED)

    provider = models.CharField(max_length=50, default="http")
    model_name = models.CharField(max_length=120, blank=True, default="")

    result_text = models.TextField(blank=True, default="")
    result_confidence = models.FloatField(null=True, blank=True)

    error = models.TextField(blank=True, default="")

    class Meta:
        indexes = [
            models.Index(fields=["status", "created_at"]),
            models.Index(fields=["trial", "created_at"]),
        ]

    def __str__(self) -> str:
        return f"ASRJob({self.id}) trial={self.trial_id} status={self.status}"
