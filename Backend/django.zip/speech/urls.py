from django.urls import path
from speech.views import (
    SpeechTrialMetaUpsertView,
    SpeechTrialAudioUploadView,
    SpeechTrialTranscribeView,
    SpeechProgressView,
)

urlpatterns = [
    path("trials/<int:trial_id>/meta", SpeechTrialMetaUpsertView.as_view(), name="speech-trial-meta"),
    path("trials/<int:trial_id>/audio", SpeechTrialAudioUploadView.as_view(), name="speech-trial-audio"),
    path("trials/<int:trial_id>/transcribe", SpeechTrialTranscribeView.as_view(), name="speech-trial-transcribe"),
    path("children/<int:child_profile_id>/progress", SpeechProgressView.as_view(), name="speech-progress"),
]
