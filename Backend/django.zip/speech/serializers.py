from __future__ import annotations

from rest_framework import serializers

from speech.models import SpeechTrialMeta, SpeechTrialAudio, ASRJob


class SpeechMetaUpsertSerializer(serializers.Serializer):
    target_text = serializers.CharField(required=False, allow_blank=True, default="")
    target_phoneme = serializers.CharField(required=False, allow_blank=True, default="")
    category = serializers.CharField(required=False, allow_blank=True, default="")
    language = serializers.CharField(required=False, allow_blank=True, default="en")
    difficulty = serializers.IntegerField(required=False, min_value=1, max_value=10, default=1)
    therapist_transcript = serializers.CharField(required=False, allow_blank=True, default="")


class SpeechTrialMetaSerializer(serializers.ModelSerializer):
    class Meta:
        model = SpeechTrialMeta
        fields = (
            "id",
            "trial",
            "target_text",
            "target_phoneme",
            "category",
            "language",
            "difficulty",
            "therapist_transcript",
            "created_at",
        )
        read_only_fields = ("id", "created_at")


class SpeechAudioUploadSerializer(serializers.Serializer):
    file = serializers.FileField()
    duration_ms = serializers.IntegerField(required=False, min_value=1)

    def validate_file(self, f):
        allowed = {
            "audio/wav",
            "audio/x-wav",
            "audio/mpeg",
            "audio/mp3",
            "audio/mp4",
            "audio/x-m4a",
            "audio/aac",
            "audio/ogg",
            "audio/webm",
        }
        ct = getattr(f, "content_type", "") or ""
        if ct and ct not in allowed:
            raise serializers.ValidationError(f"Unsupported content type: {ct}")

        max_mb = 25
        if f.size > max_mb * 1024 * 1024:
            raise serializers.ValidationError(f"File too large. Max {max_mb}MB.")
        return f


class SpeechTrialAudioSerializer(serializers.ModelSerializer):
    class Meta:
        model = SpeechTrialAudio
        fields = (
            "id",
            "trial",
            "uploaded_by",
            "uploaded_at",
            "content_type",
            "size_bytes",
            "duration_ms",
            "file",
        )
        read_only_fields = (
            "id",
            "uploaded_by",
            "uploaded_at",
            "content_type",
            "size_bytes",
        )


class ASRJobCreateSerializer(serializers.Serializer):
    model_name = serializers.CharField(required=False, allow_blank=True, default="")


class ASRJobSerializer(serializers.ModelSerializer):
    class Meta:
        model = ASRJob
        fields = (
            "id",
            "trial",
            "created_by",
            "created_at",
            "status",
            "provider",
            "model_name",
            "result_text",
            "result_confidence",
            "error",
        )
        read_only_fields = (
            "id",
            "created_by",
            "created_at",
            "status",
            "provider",
            "result_text",
            "result_confidence",
            "error",
        )
