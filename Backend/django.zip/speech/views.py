from __future__ import annotations

from django.conf import settings
from django.db.models import Avg, Count
from django.utils import timezone

from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status

from therapy.models import SessionTrial, TherapySession
from speech.models import SpeechTrialMeta, SpeechTrialAudio, ASRJob
from speech.serializers import (
    SpeechMetaUpsertSerializer,
    SpeechTrialMetaSerializer,
    SpeechAudioUploadSerializer,
    SpeechTrialAudioSerializer,
    ASRJobCreateSerializer,
    ASRJobSerializer,
)

from speech.permissions import CanAccessSpeechTrial, is_admin, is_therapist, therapist_has_child
from speech.asr_provider import ASRHTTPProvider


def _is_speech_trial(trial: SessionTrial) -> bool:
    return (trial.trial_type or "").lower() in {"speech_prompt", "speech", "speech_therapy"}


class SpeechTrialMetaUpsertView(APIView):
    permission_classes = [IsAuthenticated, CanAccessSpeechTrial]

    def post(self, request, trial_id: int):
        try:
            trial = SessionTrial.objects.select_related("session__child__user").get(id=trial_id)
        except SessionTrial.DoesNotExist:
            return Response({"detail": "Trial not found"}, status=status.HTTP_404_NOT_FOUND)

        self.check_object_permissions(request, trial)

        if not _is_speech_trial(trial):
            return Response({"detail": "This trial is not a speech trial"}, status=status.HTTP_400_BAD_REQUEST)

        ser = SpeechMetaUpsertSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        meta, _created = SpeechTrialMeta.objects.get_or_create(trial=trial)
        for k, v in ser.validated_data.items():
            setattr(meta, k, v)
        meta.save()

        return Response(SpeechTrialMetaSerializer(meta).data, status=status.HTTP_200_OK)


class SpeechTrialAudioUploadView(APIView):
    permission_classes = [IsAuthenticated, CanAccessSpeechTrial]
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request, trial_id: int):
        try:
            trial = SessionTrial.objects.select_related("session__child__user").get(id=trial_id)
        except SessionTrial.DoesNotExist:
            return Response({"detail": "Trial not found"}, status=status.HTTP_404_NOT_FOUND)

        self.check_object_permissions(request, trial)

        if not _is_speech_trial(trial):
            return Response({"detail": "This trial is not a speech trial"}, status=status.HTTP_400_BAD_REQUEST)

        ser = SpeechAudioUploadSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        f = ser.validated_data["file"]
        ct = getattr(f, "content_type", "") or ""

        audio, _created = SpeechTrialAudio.objects.get_or_create(
            trial=trial,
            defaults={
                "uploaded_by": request.user,
                "content_type": ct,
                "size_bytes": f.size,
                "duration_ms": ser.validated_data.get("duration_ms"),
                "file": f,
            }
        )

        # If already existed, replace file safely
        if not _created:
            audio.file.delete(save=False)
            audio.file = f
            audio.uploaded_by = request.user
            audio.uploaded_at = timezone.now()
            audio.content_type = ct
            audio.size_bytes = f.size
            audio.duration_ms = ser.validated_data.get("duration_ms")
            audio.save()

        return Response(SpeechTrialAudioSerializer(audio).data, status=status.HTTP_201_CREATED)


class SpeechTrialTranscribeView(APIView):
    """
    Creates an ASR job and (for Phase 1) runs it synchronously via HTTP provider if configured.
    """
    permission_classes = [IsAuthenticated, CanAccessSpeechTrial]

    def post(self, request, trial_id: int):
        try:
            trial = SessionTrial.objects.select_related("session__child__user").get(id=trial_id)
        except SessionTrial.DoesNotExist:
            return Response({"detail": "Trial not found"}, status=status.HTTP_404_NOT_FOUND)

        self.check_object_permissions(request, trial)

        if not _is_speech_trial(trial):
            return Response({"detail": "This trial is not a speech trial"}, status=status.HTTP_400_BAD_REQUEST)

        audio = getattr(trial, "speech_audio", None)
        if not audio or not audio.file:
            return Response({"detail": "No audio uploaded for this trial"}, status=status.HTTP_400_BAD_REQUEST)

        ser = ASRJobCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        job = ASRJob.objects.create(
            trial=trial,
            created_by=request.user,
            status=ASRJob.Status.QUEUED,
            provider="http",
            model_name=ser.validated_data.get("model_name", ""),
        )

        asr_url = getattr(settings, "ASR_HTTP_URL", "") or ""
        if not asr_url:
            job.status = ASRJob.Status.FAILED
            job.error = "ASR_HTTP_URL not configured. Set ASR_HTTP_URL in environment."
            job.save()
            return Response(ASRJobSerializer(job).data, status=status.HTTP_400_BAD_REQUEST)

        # Run synchronously (Phase 1). Later we move this to a worker.
        try:
            job.status = ASRJob.Status.RUNNING
            job.save(update_fields=["status"])

            provider = ASRHTTPProvider(asr_url, timeout_seconds=int(getattr(settings, "ASR_HTTP_TIMEOUT", 60)))

            # For software-only MVP, we pass a local path inside container.
            # External service should be in same network (docker compose) and access /app/media volume if shared.
            payload = {
                "audio_path": audio.file.path,
                "trial_id": trial.id,
                "model": job.model_name or "default",
            }
            result = provider.transcribe(payload)

            job.status = ASRJob.Status.SUCCEEDED
            job.result_text = result.text or ""
            job.result_confidence = result.confidence
            job.save()

            # Store suggestion into meta (therapist remains final authority)
            meta, _ = SpeechTrialMeta.objects.get_or_create(trial=trial)
            # only fill therapist_transcript if empty (do not overwrite therapist work)
            if not meta.therapist_transcript and job.result_text:
                meta.therapist_transcript = job.result_text[:500]
                meta.save(update_fields=["therapist_transcript"])

        except Exception as e:
            job.status = ASRJob.Status.FAILED
            job.error = str(e)
            job.save()

        return Response(ASRJobSerializer(job).data, status=status.HTTP_200_OK)


class SpeechProgressView(APIView):
    """
    Aggregated speech metrics per child (using generic SessionTrial scoring).
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, child_profile_id: int):
        # Admin can view all; therapist only assigned child
        from patients.models import ChildProfile
        try:
            child = ChildProfile.objects.select_related("user").get(id=child_profile_id)
        except ChildProfile.DoesNotExist:
            return Response({"detail": "Child profile not found"}, status=status.HTTP_404_NOT_FOUND)

        if not is_admin(request.user):
            if not is_therapist(request.user):
                return Response({"detail": "Forbidden"}, status=status.HTTP_403_FORBIDDEN)
            if not therapist_has_child(request.user, child.user_id):
                return Response({"detail": "Not assigned to this child"}, status=status.HTTP_403_FORBIDDEN)

        # filter speech trials only
        qs = SessionTrial.objects.filter(
            session__child_id=child_profile_id,
            trial_type__in=["speech_prompt", "speech", "speech_therapy"],
        )

        # only completed trials have score/success
        completed = qs.filter(status=SessionTrial.Status.COMPLETED)

        total = completed.count()
        avg_score = completed.aggregate(avg=Avg("score"))["avg"]
        success_rate = completed.filter(success=True).count() / total if total else 0.0

        # top categories via meta (if present)
        cat_counts = SpeechTrialMeta.objects.filter(trial__in=completed).values("category").annotate(n=Count("id")).order_by("-n")[:10]

        return Response({
            "child_profile_id": child_profile_id,
            "total_completed_speech_trials": total,
            "avg_score": avg_score,
            "success_rate": round(success_rate, 4),
            "top_categories": list(cat_counts),
        })
