from django.contrib import admin
from speech.models import SpeechTrialMeta, SpeechTrialAudio, ASRJob


@admin.register(SpeechTrialMeta)
class SpeechTrialMetaAdmin(admin.ModelAdmin):
    list_display = ("id", "trial", "target_text", "category", "language", "difficulty", "created_at")
    list_filter = ("category", "language", "difficulty")
    search_fields = ("target_text", "trial__prompt", "trial__target_behavior")


@admin.register(SpeechTrialAudio)
class SpeechTrialAudioAdmin(admin.ModelAdmin):
    list_display = ("id", "trial", "uploaded_by", "uploaded_at", "content_type", "size_bytes", "duration_ms")
    list_filter = ("content_type",)


@admin.register(ASRJob)
class ASRJobAdmin(admin.ModelAdmin):
    list_display = ("id", "trial", "status", "provider", "model_name", "created_at")
    list_filter = ("status", "provider")
