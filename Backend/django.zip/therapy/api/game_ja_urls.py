from django.urls import path
from .game_ja_views import (
    JAStartSessionAPIView,
    JANextTrialAPIView,
    JASubmitTrialAPIView,
    JASessionSummaryAPIView,
)

urlpatterns = [
    path("start/", JAStartSessionAPIView.as_view(), name="ja-start"),
    path("<int:session_id>/next/", JANextTrialAPIView.as_view(), name="ja-next"),
    path("trial/<int:trial_id>/submit/", JASubmitTrialAPIView.as_view(), name="ja-submit"),
    path("<int:session_id>/summary/", JASessionSummaryAPIView.as_view(), name="ja-summary"),
]
