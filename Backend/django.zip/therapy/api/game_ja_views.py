import random
from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated

from patients.models import ChildProfile, TherapistChildAssignment
from therapy.models import TherapySession, SessionTrial, Observation

# # Optional: consent checks (if compliance app exists)
# try:
#     from compliance.models import Consent
#     HAS_CONSENT = True
# except Exception:
HAS_CONSENT = False

from .game_ja_serializers import StartSessionSerializer, SubmitTrialSerializer

GAME_CODE = "look_where_i_point"
TRIAL_TYPE = "joint_attention"

STIMULI = ["car", "ball", "cat", "cup", "apple", "book", "fish", "hat"]


def _pick_options():
    return random.sample(STIMULI, 4)


def _compute_level_from_history(session_id: int) -> int:
    qs = SessionTrial.objects.filter(session_id=session_id, status="completed")
    total = qs.count()
    if total < 5:
        return 1

    last5 = qs.order_by("-id")[:5]
    correct = sum(1 for t in last5 if t.success is True)
    acc = correct / 5.0

    obs = Observation.objects.filter(session_id=session_id, trial_id__in=[t.id for t in last5])
    rts = []
    for o in obs:
        if isinstance(o.tags, dict) and "response_time_ms" in o.tags:
            try:
                rts.append(int(o.tags["response_time_ms"]))
            except Exception:
                pass

    avg_rt = (sum(rts) // len(rts)) if rts else None

    if acc >= 0.8 and (avg_rt is None or avg_rt <= 3000):
        return 2
    return 1


def _require_assignment(user, child: ChildProfile) -> tuple[bool, dict]:
    """
    Returns (allowed, debug) so we can see exactly why it failed.

    Your TherapistChildAssignment table (confirmed) contains:
      therapist_id, child_profile_id, child_user_id
    """
    qs = TherapistChildAssignment.objects.filter(therapist_id=user.id)

    by_child_profile = qs.filter(child_profile_id=child.id).exists()
    by_child_user = qs.filter(child_user_id=child.user_id).exists()

    return (by_child_profile or by_child_user), {
        "by_child_profile_id": by_child_profile,
        "by_child_user_id": by_child_user,
    }


def _require_consent(child: ChildProfile) -> tuple[bool, str]:
    if HAS_CONSENT:
        active = Consent.objects.filter(child=child, revoked_at__isnull=True)
        types = set(active.values_list("consent_type", flat=True))

        required = {"data", "ai"}
        missing = required - types
        if missing:
            return False, f"Missing active consent: {', '.join(sorted(missing))}"
        return True, ""
    else:
        if not getattr(child, "consent_ai", False):
            return False, "Missing consent_ai on child profile"
        return True, ""


class JAMeAPIView(APIView):
    """
    Fast debug endpoint so you can confirm your JWT maps to the expected user.
    Mount it in urls if you want:
      path("me/", JAMeAPIView.as_view())
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        u = request.user
        return Response({"id": u.id, "email": getattr(u, "email", None), "is_superuser": u.is_superuser})


class JAStartSessionAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        ser = StartSessionSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        data = ser.validated_data

        child = ChildProfile.objects.filter(id=data["child_id"], deleted_at__isnull=True).first()
        if not child:
            return Response({"detail": "Child not found"}, status=status.HTTP_404_NOT_FOUND)

        # ✅ TEMP: superuser bypass so you can demo quickly
        # Remove this once RBAC & assignments are fully enforced.
        if request.user.is_superuser:
            pass
        else:
            allowed, dbg = _require_assignment(request.user, child)
            if not allowed:
                return Response(
                    {
                        "detail": "Therapist is not assigned to this child",
                        "debug": {
                            "request_user_id": request.user.id,
                            "request_user_email": getattr(request.user, "email", None),
                            "child_profile_id": child.id,
                            "child_user_id": child.user_id,
                            **dbg,
                        },
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )

        ok, msg = _require_consent(child)
        if not ok:
            return Response({"detail": msg}, status=status.HTTP_403_FORBIDDEN)

        session = TherapySession.objects.create(
            child=child,
            therapist=request.user,
            created_by=request.user,
            supervision_mode=data.get("supervision_mode", "therapist"),
            status="in_progress",
            session_date=timezone.localdate(),
            started_at=timezone.now(),
            title=data.get("session_title", "Look Where I Point"),
        )

        trials_planned = data.get("trials_planned", 10)
        for _ in range(trials_planned):
            SessionTrial.objects.create(
                session=session,
                trial_type=TRIAL_TYPE,
                target_behavior="select_target_object",
                status="planned",
            )

        return Response(
            {
                "session_id": session.id,
                "trials_planned": trials_planned,
                "time_limit_ms": data.get("time_limit_ms", 10000),
            },
            status=status.HTTP_201_CREATED,
        )


class JANextTrialAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, session_id: int):
        session = TherapySession.objects.filter(id=session_id).select_related("child", "therapist").first()
        if not session:
            return Response({"detail": "Session not found"}, status=status.HTTP_404_NOT_FOUND)

        if session.therapist_id != request.user.id:
            return Response({"detail": "Not your session"}, status=status.HTTP_403_FORBIDDEN)

        trial = SessionTrial.objects.filter(session=session, status="planned").order_by("id").first()
        if not trial:
            return Response({"detail": "No more planned trials"}, status=status.HTTP_200_OK)

        level = _compute_level_from_history(session.id)

        options = _pick_options()
        target = random.choice(options)

        prompt = f"Look at the {target}"
        highlight = target if level == 1 else None

        trial.status = "running"
        trial.prompt = prompt
        trial.started_at = timezone.now()
        trial.save(update_fields=["status", "prompt", "started_at"])

        return Response(
            {
                "trial_id": trial.id,
                "game": GAME_CODE,
                "trial_type": TRIAL_TYPE,
                "level": level,
                "prompt": prompt,
                "highlight": highlight,
                "options": options,
                "target": target,      # MVP debug
                "time_limit_ms": 10000,
            },
            status=status.HTTP_200_OK,
        )


class JASubmitTrialAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, trial_id: int):
        ser = SubmitTrialSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        data = ser.validated_data

        trial = SessionTrial.objects.filter(id=trial_id).select_related("session", "session__therapist").first()
        if not trial:
            return Response({"detail": "Trial not found"}, status=status.HTTP_404_NOT_FOUND)

        if trial.session.therapist_id != request.user.id:
            return Response({"detail": "Not your trial"}, status=status.HTTP_403_FORBIDDEN)

        if trial.status != "running":
            return Response(
                {"detail": f"Trial not in running state (current={trial.status})"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        prompt = (trial.prompt or "").strip()
        target = prompt.split()[-1] if prompt else ""

        clicked = data["clicked"].strip().lower()
        target_norm = target.strip().lower()

        timed_out = bool(data.get("timed_out", False))
        response_time_ms = int(data["response_time_ms"])

        success = (not timed_out) and (clicked == target_norm)

        trial.success = success
        trial.score = 10 if success else 0
        trial.status = "completed"
        trial.ended_at = timezone.now()
        trial.save(update_fields=["success", "score", "status", "ended_at"])

        Observation.objects.create(
            session=trial.session,
            trial=trial,
            therapist=request.user,
            note="trial_telemetry",
            tags={
                "game": GAME_CODE,
                "level": _compute_level_from_history(trial.session_id),
                "target": target_norm,
                "clicked": clicked,
                "response_time_ms": response_time_ms,
                "timed_out": timed_out,
                "success": success,
            },
        )

        return Response({"trial_id": trial.id, "success": success, "score": trial.score}, status=status.HTTP_200_OK)


class JASessionSummaryAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, session_id: int):
        session = TherapySession.objects.filter(id=session_id).select_related("therapist").first()
        if not session:
            return Response({"detail": "Session not found"}, status=status.HTTP_404_NOT_FOUND)

        if session.therapist_id != request.user.id:
            return Response({"detail": "Not your session"}, status=status.HTTP_403_FORBIDDEN)

        trials = SessionTrial.objects.filter(session=session)
        total = trials.count()
        completed = trials.filter(status="completed").count()
        correct = trials.filter(status="completed", success=True).count()
        accuracy = (correct / completed) if completed else 0.0

        obs = Observation.objects.filter(session=session, note="trial_telemetry")
        rts = []
        for o in obs:
            if isinstance(o.tags, dict) and "response_time_ms" in o.tags:
                try:
                    rts.append(int(o.tags["response_time_ms"]))
                except Exception:
                    pass
        avg_rt = (sum(rts) // len(rts)) if rts else None

        level = _compute_level_from_history(session.id)

        suggestion = ""
        if completed and completed % 5 == 0:
            last5 = trials.filter(status="completed").order_by("-id")[:5]
            last5_correct = sum(1 for t in last5 if t.success is True)
            last5_acc = last5_correct / 5.0
            if last5_acc >= 0.8 and (avg_rt is None or avg_rt <= 3000):
                suggestion = "Suggestion: Move to Level 2 (text-only)."
            elif last5_acc < 0.5:
                suggestion = "Suggestion: Stay/return to Level 1 (highlight + text)."
            else:
                suggestion = "Suggestion: Continue at current level."

        return Response(
            {
                "session_id": session.id,
                "total_trials": total,
                "completed_trials": completed,
                "correct": correct,
                "accuracy": round(accuracy, 3),
                "avg_response_time_ms": avg_rt,
                "current_level": level,
                "suggestion": suggestion,
            },
            status=status.HTTP_200_OK,
        )
